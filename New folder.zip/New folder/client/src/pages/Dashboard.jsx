import React from "react";

const Dashboard = () => {
  return (
    <div>
      <h1>Dashboard</h1>
      <p>Here you can see how much food you have donated.</p>
    </div>
  );
};

export default Dashboard;
