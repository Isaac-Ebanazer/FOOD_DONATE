import React from "react";

const Sidebar = () => {
  return (
    <div>
      <h1>Food Donation</h1>
    </div>
  );
};

export default Sidebar;
